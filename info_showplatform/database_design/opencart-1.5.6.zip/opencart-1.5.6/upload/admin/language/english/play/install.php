<?php
$_['heading_title']                     = 'Play.com (Europe)';
$_['text_edit']                         = 'Edit';
$_['text_install']                      = 'Install';
$_['text_uninstall']                    = 'Uninstall';
$_['text_enabled']                      = 'Enabled';
$_['text_disabled']                     = 'Disabled';
$_['lang_text_success']                 = 'You have saved your changes to the Play.com extension';